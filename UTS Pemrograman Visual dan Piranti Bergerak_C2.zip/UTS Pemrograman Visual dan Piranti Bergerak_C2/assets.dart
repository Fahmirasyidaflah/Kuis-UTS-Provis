flutter:
  assets:
   - assets///picsum.photos/id/669/200
   - assets//picsum.photos/id/357/600/200
   - assets//local_grocery_store_black_24p
   - assets//search_black_24p
   - assets//chat_black_24p
   - assets//history_edu_24p