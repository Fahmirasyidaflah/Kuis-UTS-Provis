import 'package:flutter/material.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Quiz UI Flutter',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
          useMaterial3: true,
        ),
        home: const MyHomePage(title: 'Quiz UI Flutter'),
        debugShowCheckedModeBanner: false);
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  String dropdownValue = 'Perempuan';
  var items = [
    'Perempuan',
    'Laki-laki'
  ];


  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: <Widget>[
            const Text(
              'Nomor Kelompok:  23',
            ),
            const Text(
              'Mhs 1:  [2316795, Berliana Ramadhani]',
            ),
            const Text(
              'Mhs 2:  [2205324, Fahmi R.A]',
            ),
            Container(
              margin: const EdgeInsets.all(10),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) {
                    return soalNo1();
                  }));
                },
                child: const Text('   Jawaban No 1   '),
              ),
            ),
            Container(
              margin: const EdgeInsets.all(10),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) {
                    return soalNo2();
                  }));
                },
                child: const Text('   Jawaban No 2   '),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //jaawaban no 1
  Widget soalNo1() {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            color: Color(0xffe0e0e0),
          ),
          Container(
            height: 200,
            decoration: BoxDecoration(
              color: Color(0xff123456),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.all(30.0),
            child: Text(
              "Profil",
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                  fontSize: 30.0),
            ),
          ),
          SizedBox(height: 30),
          Padding(
            padding: const EdgeInsets.only(
              top: 100.0,
              right: 25.0,
              bottom: 20.0,
              left: 25.0,
            ),
            child: Container(
              height: 550,
              width: 470,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  color: Colors.black,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    //label nama lengkap
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Nama Lengkap',
                          style: TextStyle(
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold,
                              color: Color(0xff123456),),
                        ),
                      ],
                    ),
                    SizedBox(height: 5.0),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Masukkan nama lengkap',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                                borderSide: BorderSide(
                                  width: 1.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Masukkan Foto Profil',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                                borderSide: BorderSide(
                                  width: 1.0,
                                ),
                              ),
                               suffixIcon: Icon(Icons.photo_camera)
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 5.0),
                    Row(
                      children: [
                        Text(
                          'NIK',
                          style: TextStyle(
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold,
                              color: Color(0xff123456)),
                        ),
                      ],
                    ),
                    SizedBox(height: 5.0),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Masukkan NIK anda',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                                borderSide: BorderSide(
                                  width: 1.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Tanggal Lahir',
                          style: TextStyle(
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold,
                              color: Color(0xff123456)),
                        ),
                        Text(
                          'Gender',
                          style: TextStyle(
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold,
                              color: Color(0xff123456),
                              ),
                        ),
                      ],
                    ),
                    SizedBox(height: 5.0),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            readOnly: true,
                            decoration: InputDecoration(
                              hintText: 'Masukkan tanggal lahir anda',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                                borderSide: BorderSide(width: 1.0),
                              ),
                              suffixIcon: Icon(Icons.date_range_rounded)
                            ),
                           onTap: () async {
                            showDatePicker(context: context,
                            initialDate: DateTime.now(), 
                            firstDate: DateTime(2000), lastDate: DateTime(3030),);
                           },      
                          ),
                        ),
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Masukkan gender anda',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                                borderSide: BorderSide(
                                  width: 1.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          'email',
                          style: TextStyle(
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold,
                              color: Color(0xff123456)),
                        ),
                      ],
                    ),
                    SizedBox(height: 5.0),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Masukkan email anda',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                                borderSide: BorderSide(
                                  width: 1.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Text(
                          'Alamat Rumah',
                          style: TextStyle(
                              fontSize: 12.0,
                              fontWeight: FontWeight.bold,
                              color: Color(0xff123456)),
                        ),
                      ],
                    ),
                    SizedBox(height: 4.0),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Masukkan alamat rumah',
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                                borderSide: BorderSide(
                                  width: 1.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: MaterialButton(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15.0)),
                            color: Color(0xff123456),
                            onPressed: () {},
                            child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: const Text(
                                "Simpan",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  //jaawaban no 2
  Widget soalNo2() {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        ),
        body: Row("ini jawaban no 2"));
        children: [
            Expanded(
              child: Container(
                color: Colors.yellow,
                height: MediaQuery.of(context).size.height, // Menggunakan tinggi layar
                alignment: Alignment.center,
                child: Text(
                  'Kotak 1',
                  style: TextStyle(color: Colors.black, fontSize: 36.0, fontweight: bold),
                  style: TextStyle(color: Colors.black, fontSize: 24.0, fontweight: normal),
                ),
              ),
            ),
        ];
        body: Align(
            alignment: Alignment.topRight,
          child: Image.asset('assets//picsum.photos/id/669/200.jpg'), // Path ke gambar di dalam assets
        ),
        body: Align(
            alignment: Alignment.topRight,
          child: Image.asset('assets//local_grocery_store_black_24p.jpg'), // Path ke gambar di dalam assets
        ),
        body: Align(
            alignment: Alignment.topLeft,
          child: Image.asset('assets//picsum.photos/id/357/600/200.jpg'), // Path ke gambar di dalam assets
        ),
        child: Container(
        color: Colors.grey
        child: Image.asset('assets//search_black_24p.jpg'), // Path ke gambar di dalam assets
        child : Text(
          'Kotak 2',
          style: TextStyle(color: Colors.black, fontSize: 12.0, fontweight: normal),  
          )
        )
        style: TextStyle(color: Colors.black, fontSize: 24.0, fontweight: bold),
  }
}
child: Container(
        color: Colors.grey
        child: Image.asset('assets//edit_black_24p.jpg'), // Path ke gambar di dalam assets
        child : Text(
        style: TextStyle(color: Colors.black, fontSize: 12.0, fontweight: normal),  
        )
      ) 
child: Container(
        color: Colors.grey
        child: Image.asset('assets//chat_black_24p.jpg'), // Path ke gambar di dalam assets
        child : Text(
        style: TextStyle(color: Colors.black, fontSize: 12.0, fontweight: normal),  
        )
      ) 
child: Container(
        color: Colors.grey
        child: Image.asset('assets//history_edu_24p.jpg'), // Path ke gambar di dalam assets
        child : Text(
        style: TextStyle(color: Colors.black, fontSize: 12.0, fontweight: normal),  
        )
      ) 


